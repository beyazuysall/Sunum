CREATE TABLE IF NOT EXISTS orders (
    order_id SERIAL PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),
    order_date DATE NOT NULL

);


CREATE TABLE IF NOT EXISTS daily_sales_summary (
    sales_date DATE PRIMARY KEY,
    total_revenue NUMERIC(14,2) NOT NULL,
    total_quantity INTEGER NOT NULL,
    order_count INTEGER NOT NULL,
    average_order_value NUMERIC(14,2) NOT NULL

);

INSERT INTO orders
    (product_name, quantity, unit_price, order_date)
VALUES
    ('Laptop', 2, 25000, '2026-10-20'),
    ('Mouse', 5, 500, '2026-10-20'),
    ('Klavye', 3, 1500, '2026-10-21'),
    ('Monitor', 2, 8000, '2026-10-21'),
    ('Kulaklik', 4, 1200, '2026-10-22'),
    ('Mouse', 8, 500, '2026-10-23'),
    ('Monitor', 1, 8000, '2026-10-23'),
    ('Klavye', 6, 1500, '2026-10-24'),
    ('Kuaklik', 3, 1200, '2026-10-24');
