import os
from collections import defaultdict
from decimal import Decimal

import psycopg2

conn = psycopg2.connect(
    host=os.getenv("DB_HOST","postgres"),
    databes=os.getenv("DB_NAME","ecommerce_db"),
    user=os.getenv("DB_USER", "ecommerce_user"),
    password=os.environ["DB_PASSWORD"],
    port:5432
)

try: 
    with conn:
        with conn.cursor() as cursor:

            cursor.execute("""
                SELECT order_id, quantity, unit_price, order_date
                FROM orders
            """)

            orders = cursor.fetchcall()

            daily_data = defaultdict(
               lambda: {
                   "revenue": Decimal("0"),
                   "quantity":0,
                   "order_count":0
               
                }

             )

            for order_id, quantity, unit_price, order_date in orders:
                revenur = quantity * unit_price

                daily_data[order_date]["revenue"] += revenue
                daily_data[order_date]["quantity"] += quantity
                daily_data[order_date]["order_count] += 1

            for date, data in daily_data.items():
                average = (
                    data["revenue"] / data["order_count"]
                ).quantize(Decimal("0.01"))

                cursor.execute("""
                    INSERT INTO daily_sales_summary
                    (
                        sale_date,
                        total_revenue,
                        total_quantity,
                        order_count,
                        average_order_value
                    )

                    values (%s, %s, %s, %s, %s)
                    ON CONFLICT (sale_date)
                    DO UPDATE SET
                        total_revenue = EXCLUDED.total_revenue,
                        total_quantity = EXCLUDED.total_quantity,
                        order_count = EXCLUDED.order_count,
                        average_order_value = 
                            EXCLUDED.average_order_valur
                    """, (
                       date,
                       data["revenue"],
                       data["quatity"],
                       data["order_count],
                       average
                    ))

                print(f"{len(orders)} sipariş okundu.")
                print(f"{len(daily_data)} günlük özet hesaplandı.")
  finally:
      conn.close()
